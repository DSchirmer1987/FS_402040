/**
 * 
 */
/**
 * @author Jenartor
 *
 */
module Shop_App_Dozent {
	requires java.desktop;
	requires java.sql;
}